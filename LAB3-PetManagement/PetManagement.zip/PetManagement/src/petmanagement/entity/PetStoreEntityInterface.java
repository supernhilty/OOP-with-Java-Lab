package petmanagement.entity;

/**
 * Interface PetStoreEntityInterface.
 *
 * @author hasu
 */
public interface PetStoreEntityInterface {
}
