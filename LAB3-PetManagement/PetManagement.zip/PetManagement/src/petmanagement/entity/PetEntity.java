package petmanagement.entity;

import java.util.Date;
import petmanagement.main.Category;

/**
 *
 * @author leyen
 */
public class PetEntity implements PetStoreEntityInterface {

    protected String id;
    protected String name;
    protected String description;
    protected Date importDate;
    protected double price;
    protected Category category;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getImportDate() {
        return importDate;
    }

    public void setImportDate(Date importDate) {
        this.importDate = importDate;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
    
    

}
