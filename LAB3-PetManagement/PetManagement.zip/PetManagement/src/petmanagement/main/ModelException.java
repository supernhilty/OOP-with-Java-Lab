package petmanagement.main;

/**
 * Model exception.
 *
 * @author hasu
 */
public class ModelException extends Exception {

    public ModelException(String message) {
        super(message);
    }

}
