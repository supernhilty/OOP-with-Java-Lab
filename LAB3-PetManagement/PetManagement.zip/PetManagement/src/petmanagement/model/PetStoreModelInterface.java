package petmanagement.model;

/**
 * Interface UniversityModelInterface.
 * @author hasu
 */
public interface PetStoreModelInterface {
    public String getId();
    
}
